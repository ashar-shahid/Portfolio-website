// All content below is sourced directly from Ashar Shahid's resume.
// Nothing here is invented — update this file to keep the site in sync with the resume.

export const profile = {
  name: "Ashar Shahid",
  role: "Software QA Engineer",
  location: "Karachi, Pakistan",
  email: "ashar.shahid.dev@gmail.com",
  phone: "+92 317 2996072",
  linkedin: "https://linkedin.com/in/ashar-shahid-4dec02",
  linkedinLabel: "linkedin.com/in/ashar-shahid-4dec02",
  summary:
    "Detail-oriented Software Engineering graduate with hands-on Quality Assurance experience gained across two QA internships, specializing in manual testing, test case design, and defect/bug reporting. Skilled in automation testing with Selenium WebDriver and TestNG, with working knowledge of Python. Collaborates effectively with development teams to catch defects early and support reliable, on-time releases. Seeking an entry-level QA/Automation Testing role to apply a rigorous, detail-driven testing mindset.",
};

export const skillGroups = [
  {
    id: "testing",
    label: "Testing",
    skills: [
      "Manual Testing",
      "Test Case Design",
      "Regression Testing",
      "Automation Testing",
      "Bug/Defect Reporting",
      "QA Analysis",
    ],
  },
  {
    id: "automation",
    label: "Automation & Languages",
    skills: ["Selenium WebDriver", "TestNG", "Java", "Python"],
  },
  {
    id: "tools",
    label: "Tools & Practices",
    skills: ["Git", "GitHub", "Jira", "SDLC", "Cross-Functional Collaboration"],
  },
  {
    id: "other",
    label: "Other Technologies",
    skills: ["Hyperledger Fabric", "FastAPI", "AI/ML (Fraud Detection)"],
  },
];

// status: "active" | "passed" — mirrors QA test-run states (ongoing vs. completed)
export const experience = [
  {
    id: "TC-EXP-03",
    company: "10Pearls Pakistan",
    role: "Quality Assurance Intern — Shine Internship",
    duration: "Jul 2026 – Present",
    location: "Remote",
    status: "active",
    statusLabel: "ONGOING",
    bullets: [
      "Execute manual test cases and apply automation testing practices to support software quality on live projects during the 10Pearls Shine Internship.",
      "Support QA analysis and adherence to quality assurance standards, collaborating with a remote engineering team to strengthen test coverage.",
    ],
    tags: ["Manual Testing", "Automation", "QA Standards"],
  },
  {
    id: "TC-EXP-02",
    company: "DevelopersHub Corporation",
    role: "Software Quality Assurance Intern",
    duration: "Apr 2026 – Jun 2026",
    location: "Karachi, Pakistan (Remote)",
    status: "passed",
    statusLabel: "COMPLETED",
    note: "Certificate of Achievement No. DHC 1725",
    bullets: [
      "Completed a 6-week Software Quality Assurance internship, designing and executing test cases to validate application functionality against requirements.",
      "Performed manual testing and documented defects through structured bug reports, collaborating with developers to track issues to resolution.",
      "Applied QA processes and best practices while gaining hands-on exposure to Selenium WebDriver and TestNG for automation testing, contributing to measurable improvements in project quality.",
    ],
    tags: ["Manual Testing", "Selenium WebDriver", "TestNG", "Bug Reporting"],
  },
  {
    id: "TC-EXP-01",
    company: "Dar Al Medhyaf",
    role: "IT Support (Part-Time)",
    duration: "Oct 2024 – Present",
    location: "Kuwait (Remote)",
    status: "active",
    statusLabel: "ONGOING",
    bullets: [
      "Diagnose and resolve technical issues using a structured, root-cause troubleshooting approach — a defect-identification method aligned with QA methodology.",
      "Coordinate with vendors and internal stakeholders to define requirements and track deliverables, applying attention to detail to reduce delivery delays.",
      "Monitor multiple concurrent project timelines and proactively flag risks, supporting consistent quality and on-time delivery.",
    ],
    tags: ["Root-Cause Analysis", "Stakeholder Coordination"],
  },
];

// status: "shipped" | "in-progress"
export const projects = [
  {
    id: "TC-PRJ-02",
    name: "Secure Blockchain-Based Electronic Voting System",
    subtitle: "Final Year Project",
    status: "in-progress",
    statusLabel: "IN PROGRESS",
    description:
      "A blockchain-based electronic voting platform on Hyperledger Fabric built to keep vote recording transparent and tamper-resistant.",
    contribution:
      "Designing and developing the core voting platform, plus an AI-powered fraud detection module (Python, FastAPI) that analyzes voting behavior and metadata to assign fraud risk scores and flag suspicious votes for review — strengthening platform security.",
    tech: ["Hyperledger Fabric", "Python", "FastAPI", "AI/ML"],
    featured: true,
  },
  {
    id: "TC-PRJ-01",
    name: "Tools Hub",
    subtitle: "Personal Project",
    status: "shipped",
    statusLabel: "SHIPPED",
    description:
      "A multi-tool web application combining image compression, an advanced calculator, and a matrix solver.",
    contribution:
      "Built and verified each module for functional accuracy. Engineered the matrix solver to output step-by-step calculation details, making results easy to verify — a quality-focused, detail-oriented approach to the build.",
    tech: ["JavaScript", "Web App"],
    featured: false,
  },
  {
    id: "TC-PRJ-00",
    name: "Gadget Bazar",
    subtitle: "Semester Project",
    status: "shipped",
    statusLabel: "SHIPPED",
    description:
      "A full e-commerce web application for browsing, filtering, and managing gadget listings with integrated cart functionality.",
    contribution:
      "Collaborated within a team to implement and validate core e-commerce workflows from requirements through delivery, functionally verifying each feature.",
    tech: ["E-Commerce", "Team Project"],
    featured: false,
  },
];

export const education = [
  {
    school: "Sir Syed University of Engineering & Technology",
    degree: "BS in Software Engineering",
    detail: "CGPA: 3.51 / 4.0",
    duration: "Expected Jul 2026",
    location: "Karachi, Pakistan",
    extra:
      "Relevant Coursework: Software Engineering, Web Development, Database Systems, Data Structures & Algorithms, Computer Networks & Cryptography",
  },
  {
    school: "Government Dehli College",
    degree: "Intermediate (Pre-Engineering)",
    detail: "80%",
    duration: "2021",
    location: "",
    extra: "",
  },
];

export const leadership = {
  role: "Class Representative (Section A)",
  org: "Sir Syed University of Engineering & Technology",
  duration: "Feb 2025 – Present",
  bullets: [
    "Serve as primary liaison between students and faculty, resolving academic and administrative issues.",
    "Coordinate class activities and communications across the section.",
  ],
};
