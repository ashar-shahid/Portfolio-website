// ─────────────────────────────────────────────────────────────────────────
// CERTIFICATE DATA — this is the ONLY file you need to edit to add a
// certificate to the live site.
//
// HOW TO ADD A CERTIFICATE:
//   1. Drop the image/PDF file into the matching folder under:
//        public/certificates/manual-and-qa-testing/
//        public/certificates/automation-testing/
//        public/certificates/programming/
//        public/certificates/other/
//      (create a new category folder if none of these fit)
//   2. Add an entry to the `certificates` array below, pointing `file` at
//      the public path of the file you just added.
//   3. Commit + push to GitHub — Vercel redeploys automatically and the
//      certificate appears on the live site.
//
// No certificate files were provided when this site was generated, so the
// array below starts empty and the Certifications section will show a
// "certificates coming soon" state until entries are added.
// ─────────────────────────────────────────────────────────────────────────

export const categories = [
  { id: "manual-and-qa-testing", label: "Manual & QA Testing" },
  { id: "automation-testing", label: "Automation Testing" },
  { id: "programming", label: "Programming" },
  { id: "other", label: "Other" },
];

/**
 * @typedef {Object} Certificate
 * @property {string} id             - unique slug, e.g. "istqb-foundation"
 * @property {string} title          - certificate title
 * @property {string} organization   - issuing organization
 * @property {string} category       - one of the category ids above
 * @property {string} date           - year or date string
 * @property {string} file           - public path, e.g. "/certificates/programming/cert.png"
 * @property {"image"|"pdf"} type    - file type, used to pick the viewer
 * @property {string} [credentialId] - optional credential ID
 * @property {string} [credentialUrl]- optional verification link
 */

/** @type {Certificate[]} */
export const certificates = [
  // Example (remove the leading "//" on each line and fill in real values):
  // {
  //   id: "example-cert",
  //   title: "Example Certificate Title",
  //   organization: "Issuing Organization",
  //   category: "manual-and-qa-testing",
  //   date: "2026",
  //   file: "/certificates/manual-and-qa-testing/example-cert.png",
  //   type: "image",
  //   credentialId: "ABC-123",
  //   credentialUrl: "https://verify.example.com/abc-123",
  // },
];
