export default function StatusBadge({ tone = "pass", children }) {
  const styles =
    tone === "pass"
      ? "bg-pass-dim text-pass border-pass/20"
      : "bg-amber-dim text-amber border-amber/20";

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-mono-tag font-medium uppercase tracking-wider ${styles}`}
    >
      <span
        className={`h-1.5 w-1.5 rounded-full ${
          tone === "pass" ? "bg-pass" : "bg-amber"
        }`}
      />
      {children}
    </span>
  );
}
