import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { FileText, Award } from "lucide-react";
import SectionHeading from "./SectionHeading";
import CertificateModal from "./CertificateModal";
import { certificates, categories } from "../data/certificates";

export default function Certifications() {
  const [activeCategory, setActiveCategory] = useState("all");
  const [selected, setSelected] = useState(null);

  const usedCategories = useMemo(
    () => categories.filter((c) => certificates.some((cert) => cert.category === c.id)),
    []
  );

  const visible =
    activeCategory === "all"
      ? certificates
      : certificates.filter((c) => c.category === activeCategory);

  return (
    <section id="certifications" className="py-20 md:py-28 border-t border-line">
      <div className="max-w-6xl mx-auto px-5 md:px-8">
        <SectionHeading
          tag="05 · Certifications"
          title="Credentials on file."
          description="Organized by discipline — click any certificate to view it in full."
        />

        {certificates.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="mt-14 rounded-lg border border-dashed border-line-strong p-12 text-center"
          >
            <Award className="mx-auto text-steel-light mb-4" size={28} />
            <p className="font-mono-tag text-sm text-steel-light uppercase tracking-wider">
              No certificates on file yet
            </p>
            <p className="text-steel text-sm mt-2 max-w-sm mx-auto">
              Add certificate files to <code className="text-ink">public/certificates/</code> and an
              entry to <code className="text-ink">src/data/certificates.js</code> to have them
              appear here.
            </p>
          </motion.div>
        ) : (
          <>
            <div className="mt-10 flex flex-wrap gap-2">
              <button
                onClick={() => setActiveCategory("all")}
                className={`text-xs font-mono-tag uppercase tracking-wider px-3.5 py-2 rounded-full border transition-colors ${
                  activeCategory === "all"
                    ? "bg-ink text-paper border-ink"
                    : "border-line-strong text-steel hover:border-ink"
                }`}
              >
                All
              </button>
              {usedCategories.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setActiveCategory(c.id)}
                  className={`text-xs font-mono-tag uppercase tracking-wider px-3.5 py-2 rounded-full border transition-colors ${
                    activeCategory === c.id
                      ? "bg-ink text-paper border-ink"
                      : "border-line-strong text-steel hover:border-ink"
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>

            <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {visible.map((cert, i) => (
                <motion.button
                  key={cert.id}
                  initial={{ opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-40px" }}
                  transition={{ duration: 0.4, delay: (i % 6) * 0.05 }}
                  onClick={() => setSelected(cert)}
                  className="text-left rounded-lg border border-line-strong bg-white/60 overflow-hidden hover:border-ink/30 transition-colors group"
                >
                  <div className="aspect-[4/3] bg-paper-dim flex items-center justify-center overflow-hidden">
                    {cert.type === "image" ? (
                      <img
                        src={cert.file}
                        alt={cert.title}
                        loading="lazy"
                        className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-300"
                      />
                    ) : (
                      <FileText className="text-steel-light" size={32} />
                    )}
                  </div>
                  <div className="p-4">
                    <p className="font-mono-tag text-[11px] text-pass uppercase tracking-wider mb-1">
                      {cert.organization}
                    </p>
                    <h3 className="font-display text-[15px] font-semibold text-ink leading-snug">
                      {cert.title}
                    </h3>
                    {cert.date && (
                      <p className="text-xs text-steel-light mt-1.5 font-mono-tag">{cert.date}</p>
                    )}
                  </div>
                </motion.button>
              ))}
            </div>
          </>
        )}
      </div>

      <CertificateModal certificate={selected} onClose={() => setSelected(null)} />
    </section>
  );
}
