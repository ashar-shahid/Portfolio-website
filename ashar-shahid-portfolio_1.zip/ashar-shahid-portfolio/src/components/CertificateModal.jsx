import { useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, ExternalLink, Download } from "lucide-react";

export default function CertificateModal({ certificate, onClose }) {
  useEffect(() => {
    if (!certificate) return;
    const onKey = (e) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [certificate, onClose]);

  return (
    <AnimatePresence>
      {certificate && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8"
          onClick={onClose}
        >
          <div className="absolute inset-0 bg-ink/70 backdrop-blur-sm" />

          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.98 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
            onClick={(e) => e.stopPropagation()}
            className="relative z-10 bg-paper rounded-lg border border-line-strong w-full max-w-3xl max-h-[88vh] overflow-hidden flex flex-col"
          >
            <div className="flex items-start justify-between gap-4 px-6 py-5 border-b border-line">
              <div>
                <p className="font-mono-tag text-xs text-pass uppercase tracking-wider mb-1">
                  {certificate.organization}
                </p>
                <h3 className="font-display text-lg md:text-xl font-semibold text-ink">
                  {certificate.title}
                </h3>
              </div>
              <button
                onClick={onClose}
                aria-label="Close"
                className="shrink-0 text-steel hover:text-ink transition-colors mt-1"
              >
                <X size={20} />
              </button>
            </div>

            <div className="flex-1 overflow-auto bg-paper-dim flex items-center justify-center p-6">
              {certificate.type === "pdf" ? (
                <iframe
                  src={certificate.file}
                  title={certificate.title}
                  className="w-full h-[60vh] rounded border border-line bg-white"
                />
              ) : (
                <img
                  src={certificate.file}
                  alt={certificate.title}
                  className="max-h-[60vh] w-auto rounded border border-line bg-white object-contain"
                />
              )}
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-4 border-t border-line text-sm">
              <div className="text-steel font-mono-tag text-xs space-x-4">
                {certificate.date && <span>{certificate.date}</span>}
                {certificate.credentialId && (
                  <span>ID: {certificate.credentialId}</span>
                )}
              </div>
              <div className="flex items-center gap-3">
                {certificate.credentialUrl && (
                  <a
                    href={certificate.credentialUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 text-pass hover:underline"
                  >
                    Verify <ExternalLink size={13} />
                  </a>
                )}
                <a
                  href={certificate.file}
                  download
                  className="inline-flex items-center gap-1.5 rounded-md border border-line-strong px-3 py-1.5 text-ink hover:border-ink transition-colors"
                >
                  <Download size={13} /> Download
                </a>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
