import { motion } from "framer-motion";

export default function SectionHeading({ tag, title, description, align = "left" }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className={align === "center" ? "text-center" : ""}
    >
      <div className="flex items-center gap-3 mb-3 justify-start">
        {align === "center" && <span className="hidden" />}
        <span className="font-mono-tag text-xs text-pass uppercase tracking-[0.18em]">
          {tag}
        </span>
        <span className="h-px flex-1 bg-line max-w-16" />
      </div>
      <h2 className="font-display text-3xl md:text-[2.6rem] font-semibold text-ink leading-[1.1] tracking-tight">
        {title}
      </h2>
      {description && (
        <p className="mt-4 text-steel text-base md:text-lg max-w-2xl leading-relaxed">
          {description}
        </p>
      )}
    </motion.div>
  );
}
