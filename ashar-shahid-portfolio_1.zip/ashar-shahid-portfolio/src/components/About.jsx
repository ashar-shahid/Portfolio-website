import SectionHeading from "./SectionHeading";
import { motion } from "framer-motion";

export default function About() {
  return (
    <section id="about" className="py-20 md:py-28 border-t border-line">
      <div className="max-w-6xl mx-auto px-5 md:px-8 grid md:grid-cols-[0.9fr_1.1fr] gap-12 md:gap-16">
        <SectionHeading tag="01 · About" title="Trained to find what breaks first." />

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.5 }}
          className="space-y-5 text-steel text-base md:text-lg leading-relaxed"
        >
          <p>
            I'm a final-year Software Engineering student at Sir Syed
            University of Engineering & Technology, graduating in 2026, and
            I've spent the last few internships doing something most
            developers try to avoid: actively looking for the parts of an
            application that don't work.
          </p>
          <p>
            That's what QA is to me — not a gate at the end of a sprint, but
            a discipline you build into how you think. It started with
            writing manual test cases and structured bug reports at{" "}
            <span className="text-ink font-medium">DevelopersHub Corporation</span>,
            and it's continuing now at{" "}
            <span className="text-ink font-medium">10Pearls</span>, where I'm
            pairing that manual rigor with automation using{" "}
            <span className="text-ink font-medium">Selenium WebDriver</span> and{" "}
            <span className="text-ink font-medium">TestNG</span>.
          </p>
          <p>
            I like projects that force precision. My final year project — a
            blockchain-based electronic voting system on Hyperledger Fabric —
            exists because tamper-resistant vote recording only matters if
            the system is actually verified to be tamper-resistant, so I'm
            building an AI-powered fraud detection layer alongside it to
            catch what a casual glance would miss.
          </p>
          <p>
            Outside of QA work, I serve as Class Representative for my
            section at university, coordinating between students and
            faculty — a role that, like testing, mostly comes down to
            catching problems early and communicating them clearly.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
