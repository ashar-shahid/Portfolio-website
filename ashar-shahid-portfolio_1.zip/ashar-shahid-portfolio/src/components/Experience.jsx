import { motion } from "framer-motion";
import { MapPin } from "lucide-react";
import SectionHeading from "./SectionHeading";
import StatusBadge from "./StatusBadge";
import { experience } from "../data/resumeData";

export default function Experience() {
  return (
    <section id="experience" className="py-20 md:py-28 border-t border-line">
      <div className="max-w-6xl mx-auto px-5 md:px-8">
        <SectionHeading
          tag="02 · Experience"
          title="Where the testing happened."
          description="Each role logged like a test run — what I was assigned, and the outcome."
        />

        <div className="mt-14 relative">
          <div className="absolute left-[7px] top-2 bottom-2 w-px bg-line hidden md:block" />

          <div className="space-y-6">
            {experience.map((job, i) => (
              <motion.div
                key={job.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.5, delay: i * 0.06 }}
                className="relative md:pl-10"
              >
                <span
                  className={`absolute left-0 top-6 hidden md:block h-3.5 w-3.5 rounded-full border-2 border-paper ring-2 ${
                    job.status === "active"
                      ? "bg-amber ring-amber/30"
                      : "bg-pass ring-pass/30"
                  }`}
                />

                <div className="rounded-lg border border-line-strong bg-white/60 p-6 md:p-7 hover:border-ink/30 transition-colors">
                  <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
                    <div>
                      <span className="font-mono-tag text-xs text-steel-light">
                        {job.id}
                      </span>
                      <h3 className="font-display text-xl font-semibold text-ink mt-1">
                        {job.role}
                      </h3>
                      <p className="text-steel text-sm mt-0.5">{job.company}</p>
                    </div>
                    <StatusBadge tone={job.status === "active" ? "amber" : "pass"}>
                      {job.statusLabel}
                    </StatusBadge>
                  </div>

                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-steel-light font-mono-tag mb-5">
                    <span>{job.duration}</span>
                    <span className="flex items-center gap-1">
                      <MapPin size={12} /> {job.location}
                    </span>
                    {job.note && <span>{job.note}</span>}
                  </div>

                  <ul className="space-y-2.5">
                    {job.bullets.map((b) => (
                      <li key={b} className="flex gap-2.5 text-sm md:text-[15px] text-steel leading-relaxed">
                        <span className="text-pass mt-1.5 shrink-0">▸</span>
                        {b}
                      </li>
                    ))}
                  </ul>

                  <div className="flex flex-wrap gap-2 mt-5">
                    {job.tags.map((t) => (
                      <span
                        key={t}
                        className="text-[11px] font-mono-tag text-steel bg-paper-dim border border-line px-2.5 py-1 rounded"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
