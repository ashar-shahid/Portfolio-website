import { profile } from "../data/resumeData";

export default function Footer() {
  return (
    <footer className="border-t border-line py-8">
      <div className="max-w-6xl mx-auto px-5 md:px-8 flex flex-wrap items-center justify-between gap-3">
        <p className="font-mono-tag text-xs text-steel-light">
          © {new Date().getFullYear()} {profile.name}
        </p>
        <p className="font-mono-tag text-xs text-steel-light">
          Built with React · Tailwind CSS
        </p>
      </div>
    </footer>
  );
}
