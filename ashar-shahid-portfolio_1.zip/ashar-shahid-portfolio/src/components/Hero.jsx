import { motion } from "framer-motion";
import { ArrowRight, Download, Mail } from "lucide-react";
import { profile } from "../data/resumeData";

const LOG_LINES = [
  { text: "run --suite=career --verbose", type: "cmd" },
  { text: "manual_testing.spec ............. PASS", type: "pass" },
  { text: "test_case_design.spec ............ PASS", type: "pass" },
  { text: "automation.spec (selenium/testng)  PASS", type: "pass" },
  { text: "voting_system.fyp ........ IN PROGRESS", type: "amber" },
  { text: "3 passed, 1 running · 0 failed", type: "summary" },
];

export default function Hero() {
  return (
    <section id="top" className="relative pt-32 pb-20 md:pt-44 md:pb-28 bg-grain">
      <div className="max-w-6xl mx-auto px-5 md:px-8 grid md:grid-cols-[1.15fr_0.85fr] gap-14 items-center">
        <div>
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="font-mono-tag text-xs uppercase tracking-[0.2em] text-pass mb-5"
          >
            Karachi, Pakistan · Available for QA roles
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.08 }}
            className="font-display text-[2.6rem] leading-[1.05] md:text-6xl font-semibold text-ink tracking-tight"
          >
            {profile.name}
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.16 }}
            className="mt-4 text-lg md:text-xl text-steel max-w-xl leading-relaxed"
          >
            Software QA Engineer who catches what others ship past. I design
            test cases, run them by hand and by script, and write the bug
            report that stops a bad build before release.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.24 }}
            className="mt-9 flex flex-wrap items-center gap-3"
          >
            <a
              href="#projects"
              className="inline-flex items-center gap-2 rounded-md bg-ink text-paper px-5 py-3 text-sm font-medium hover:bg-ink/85 transition-colors"
            >
              View Projects
              <ArrowRight size={15} />
            </a>
            <a
              href="/resume/Ashar_Shahid_Resume.pdf"
              download
              className="inline-flex items-center gap-2 rounded-md border border-line-strong px-5 py-3 text-sm font-medium text-ink hover:border-ink transition-colors"
            >
              <Download size={15} />
              Download Resume
            </a>
            <a
              href="#contact"
              className="inline-flex items-center gap-2 px-2 py-3 text-sm font-medium text-steel hover:text-ink transition-colors"
            >
              <Mail size={15} />
              Contact Me
            </a>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="rounded-lg border border-line-strong bg-ink text-[13px] font-mono-tag overflow-hidden shadow-[0_18px_40px_-20px_rgba(20,23,26,0.35)]"
        >
          <div className="flex items-center gap-1.5 px-4 py-3 border-b border-white/10">
            <span className="h-2.5 w-2.5 rounded-full bg-white/20" />
            <span className="h-2.5 w-2.5 rounded-full bg-white/20" />
            <span className="h-2.5 w-2.5 rounded-full bg-white/20" />
            <span className="ml-3 text-white/40 text-xs">qa-runner — zsh</span>
          </div>
          <div className="px-5 py-5 space-y-2.5">
            {LOG_LINES.map((line, i) => (
              <motion.div
                key={line.text}
                initial={{ opacity: 0, x: -6 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.35, delay: 0.6 + i * 0.22 }}
                className={
                  line.type === "cmd"
                    ? "text-white/70"
                    : line.type === "pass"
                    ? "text-[#5FCFA0]"
                    : line.type === "amber"
                    ? "text-[#E3A25C]"
                    : "text-white/45 pt-1"
                }
              >
                {line.type === "cmd" ? (
                  <span>
                    <span className="text-[#5FCFA0]">$</span> {line.text}
                  </span>
                ) : (
                  <span>{line.type !== "summary" && "✓ "}{line.text}</span>
                )}
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
