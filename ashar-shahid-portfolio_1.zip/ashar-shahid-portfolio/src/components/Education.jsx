import { motion } from "framer-motion";
import SectionHeading from "./SectionHeading";
import { education, leadership } from "../data/resumeData";

export default function Education() {
  return (
    <section id="education" className="py-20 md:py-28 border-t border-line bg-paper-dim/40">
      <div className="max-w-6xl mx-auto px-5 md:px-8 grid md:grid-cols-2 gap-14">
        <div>
          <SectionHeading tag="06 · Education" title="Formal record." />
          <div className="mt-10 space-y-6">
            {education.map((ed, i) => (
              <motion.div
                key={ed.school}
                initial={{ opacity: 0, y: 14 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.45, delay: i * 0.06 }}
                className="border-l-2 border-line pl-5"
              >
                <p className="font-mono-tag text-xs text-steel-light">{ed.duration}</p>
                <h3 className="font-display text-lg font-semibold text-ink mt-1">
                  {ed.school}
                </h3>
                <p className="text-steel text-sm mt-0.5">
                  {ed.degree} {ed.detail && <span className="text-ink">· {ed.detail}</span>}
                </p>
                {ed.location && <p className="text-steel-light text-xs mt-1">{ed.location}</p>}
                {ed.extra && (
                  <p className="text-steel text-sm mt-2 leading-relaxed">{ed.extra}</p>
                )}
              </motion.div>
            ))}
          </div>
        </div>

        <div>
          <SectionHeading tag="07 · Leadership" title="Beyond the codebase." />
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.45 }}
            className="mt-10 border-l-2 border-line pl-5"
          >
            <p className="font-mono-tag text-xs text-steel-light">{leadership.duration}</p>
            <h3 className="font-display text-lg font-semibold text-ink mt-1">
              {leadership.role}
            </h3>
            <p className="text-steel text-sm mt-0.5">{leadership.org}</p>
            <ul className="mt-3 space-y-2">
              {leadership.bullets.map((b) => (
                <li key={b} className="flex gap-2.5 text-sm text-steel leading-relaxed">
                  <span className="text-pass mt-1.5 shrink-0">▸</span>
                  {b}
                </li>
              ))}
            </ul>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
