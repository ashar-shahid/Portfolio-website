import { motion } from "framer-motion";
import SectionHeading from "./SectionHeading";
import StatusBadge from "./StatusBadge";
import { projects } from "../data/resumeData";

function ProjectCard({ project, featured, index }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.5, delay: index * 0.06 }}
      className={`rounded-lg border bg-white/60 hover:border-ink/30 transition-colors ${
        featured
          ? "border-line-strong p-7 md:p-9 md:col-span-2"
          : "border-line-strong p-6 md:p-7"
      }`}
    >
      <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
        <div>
          <span className="font-mono-tag text-xs text-steel-light">
            {project.id}
          </span>
          <h3
            className={`font-display font-semibold text-ink mt-1 ${
              featured ? "text-2xl md:text-[1.7rem]" : "text-xl"
            }`}
          >
            {project.name}
          </h3>
          <p className="text-steel text-sm mt-0.5">{project.subtitle}</p>
        </div>
        <StatusBadge tone={project.status === "shipped" ? "pass" : "amber"}>
          {project.statusLabel}
        </StatusBadge>
      </div>

      <p className="text-steel text-sm md:text-[15px] leading-relaxed mb-3">
        {project.description}
      </p>
      <p className="text-ink/80 text-sm md:text-[15px] leading-relaxed">
        {project.contribution}
      </p>

      <div className="flex flex-wrap gap-2 mt-6">
        {project.tech.map((t) => (
          <span
            key={t}
            className="text-[11px] font-mono-tag text-steel bg-paper-dim border border-line px-2.5 py-1 rounded"
          >
            {t}
          </span>
        ))}
      </div>
    </motion.div>
  );
}

export default function Projects() {
  const featured = projects.find((p) => p.featured);
  const rest = projects.filter((p) => !p.featured);

  return (
    <section id="projects" className="py-20 md:py-28 border-t border-line bg-paper-dim/40">
      <div className="max-w-6xl mx-auto px-5 md:px-8">
        <SectionHeading
          tag="03 · Projects"
          title="What I've actually built."
          description="From a security-critical final year project to smaller tools built and verified end to end."
        />

        <div className="mt-14 grid md:grid-cols-2 gap-6">
          {featured && <ProjectCard project={featured} featured index={0} />}
          {rest.map((p, i) => (
            <ProjectCard project={p} key={p.id} index={i + 1} />
          ))}
        </div>
      </div>
    </section>
  );
}
