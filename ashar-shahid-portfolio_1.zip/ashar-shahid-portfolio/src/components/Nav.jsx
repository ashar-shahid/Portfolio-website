import { useEffect, useState } from "react";
import { Menu, X, Download } from "lucide-react";

const LINKS = [
  { href: "#about", label: "About" },
  { href: "#experience", label: "Experience" },
  { href: "#projects", label: "Projects" },
  { href: "#skills", label: "Skills" },
  { href: "#certifications", label: "Certifications" },
  { href: "#contact", label: "Contact" },
];

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-paper/90 backdrop-blur-md border-b border-line" : "border-b border-transparent"
      }`}
    >
      <nav className="max-w-6xl mx-auto px-5 md:px-8 h-16 flex items-center justify-between">
        <a
          href="#top"
          className="font-mono-tag text-sm font-medium text-ink flex items-center gap-2"
        >
          <span className="text-pass">$</span> ashar<span className="text-steel-light">.shahid</span>
        </a>

        <div className="hidden md:flex items-center gap-8">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-sm text-steel hover:text-ink transition-colors"
            >
              {l.label}
            </a>
          ))}
        </div>

        <div className="hidden md:block">
          <a
            href="/resume/Ashar_Shahid_Resume.pdf"
            download
            className="inline-flex items-center gap-2 rounded-md border border-ink px-4 py-2 text-sm font-medium text-ink hover:bg-ink hover:text-paper transition-colors"
          >
            <Download size={15} strokeWidth={2} />
            Resume
          </a>
        </div>

        <button
          className="md:hidden text-ink"
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle menu"
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </nav>

      {open && (
        <div className="md:hidden bg-paper border-t border-line px-5 py-4 flex flex-col gap-4">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="text-sm text-steel hover:text-ink transition-colors"
            >
              {l.label}
            </a>
          ))}
          <a
            href="/resume/Ashar_Shahid_Resume.pdf"
            download
            className="inline-flex items-center justify-center gap-2 rounded-md border border-ink px-4 py-2 text-sm font-medium text-ink"
          >
            <Download size={15} />
            Download Resume
          </a>
        </div>
      )}
    </header>
  );
}
