import { motion } from "framer-motion";
import { Mail, Phone, MapPin, ArrowUpRight, Download } from "lucide-react";

function LinkedInIcon({ size = 20, ...props }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" {...props}>
      <path d="M6.94 8.5v9M6.94 5.5v.01M11.5 17.5v-5.2c0-1.6 1-2.8 2.6-2.8 1.5 0 2.4 1 2.4 2.9v5.1" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M11.5 8.5v9" strokeLinecap="round" />
      <rect x="3" y="3" width="18" height="18" rx="3" />
    </svg>
  );
}
import SectionHeading from "./SectionHeading";
import { profile } from "../data/resumeData";

const LINKS = [
  {
    icon: Mail,
    label: "Email",
    value: profile.email,
    href: `mailto:${profile.email}`,
  },
  {
    icon: Phone,
    label: "Phone",
    value: profile.phone,
    href: `tel:${profile.phone.replace(/\s+/g, "")}`,
  },
  {
    icon: LinkedInIcon,
    label: "LinkedIn",
    value: profile.linkedinLabel,
    href: profile.linkedin,
  },
  {
    icon: MapPin,
    label: "Location",
    value: profile.location,
    href: null,
  },
];

export default function Contact() {
  return (
    <section id="contact" className="py-20 md:py-28 border-t border-line">
      <div className="max-w-6xl mx-auto px-5 md:px-8">
        <SectionHeading
          tag="08 · Contact"
          title="Let's talk about an opening."
          description="Open to entry-level QA and automation testing roles. Reach out directly — every channel below goes straight to me."
        />

        <div className="mt-14 grid sm:grid-cols-2 gap-5">
          {LINKS.map((l, i) => {
            const Icon = l.icon;
            const content = (
              <>
                <div className="flex items-center justify-between">
                  <Icon className="text-pass" size={20} strokeWidth={1.75} />
                  {l.href && <ArrowUpRight className="text-steel-light group-hover:text-ink transition-colors" size={16} />}
                </div>
                <p className="font-mono-tag text-xs text-steel-light uppercase tracking-wider mt-5">
                  {l.label}
                </p>
                <p className="text-ink text-base md:text-lg font-medium mt-1 break-words">
                  {l.value}
                </p>
              </>
            );

            return (
              <motion.div
                key={l.label}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.45, delay: i * 0.06 }}
              >
                {l.href ? (
                  <a
                    href={l.href}
                    target={l.href.startsWith("http") ? "_blank" : undefined}
                    rel={l.href.startsWith("http") ? "noreferrer" : undefined}
                    className="group block rounded-lg border border-line-strong bg-white/60 p-6 hover:border-ink/30 transition-colors h-full"
                  >
                    {content}
                  </a>
                ) : (
                  <div className="rounded-lg border border-line-strong bg-white/60 p-6 h-full">
                    {content}
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.45, delay: 0.2 }}
          className="mt-6 rounded-lg border border-line-strong bg-ink px-6 py-7 md:px-9 md:py-9 flex flex-wrap items-center justify-between gap-6"
        >
          <div>
            <p className="font-mono-tag text-xs text-pass uppercase tracking-wider mb-2">
              Full resume
            </p>
            <p className="text-paper text-lg font-medium">
              Every role, project, and certification — one PDF.
            </p>
          </div>
          <a
            href="/resume/Ashar_Shahid_Resume.pdf"
            download
            className="inline-flex items-center gap-2 rounded-md bg-paper text-ink px-5 py-3 text-sm font-medium hover:bg-paper/90 transition-colors shrink-0"
          >
            <Download size={15} />
            Download Resume
          </a>
        </motion.div>
      </div>
    </section>
  );
}
