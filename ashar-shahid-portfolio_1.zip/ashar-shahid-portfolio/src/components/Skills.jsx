import { motion } from "framer-motion";
import SectionHeading from "./SectionHeading";
import { skillGroups } from "../data/resumeData";

export default function Skills() {
  return (
    <section id="skills" className="py-20 md:py-28 border-t border-line">
      <div className="max-w-6xl mx-auto px-5 md:px-8">
        <SectionHeading tag="04 · Skills" title="The toolkit." />

        <div className="mt-14 grid sm:grid-cols-2 gap-x-10 gap-y-10">
          {skillGroups.map((group, i) => (
            <motion.div
              key={group.id}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.45, delay: i * 0.06 }}
            >
              <h3 className="font-mono-tag text-xs uppercase tracking-[0.15em] text-steel-light mb-4 pb-3 border-b border-line">
                {group.label}
              </h3>
              <div className="flex flex-wrap gap-2">
                {group.skills.map((s) => (
                  <span
                    key={s}
                    className="text-sm text-ink bg-white border border-line-strong px-3 py-1.5 rounded-md"
                  >
                    {s}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
